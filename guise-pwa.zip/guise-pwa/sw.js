 
var cacheName = 'epwa';

var filesToCache = [ 
  '/',
  'index.html',
  'sw.js',
  'manifest.json',
  'favicon.png', 

  'css/style.css',
  'css/bootstrap.min.css',
  'css/font-awesome.min.css',
  'fonts/*',
  'img/logo-guise.png',
  'img/apple_imac_ipad_iphone_yellow_31029_1280x720.jpg',
  'https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap' 
]; 
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').then(function() {
    console.log('sw: registration ok');
  }).catch(function(err) {
    console.error(err);
  });
} 
/**
 * 'Install' event. Writing files to browser cache
 *
 * @param {string} Event name ('install')
 * @param {function} Callback function with event data
 *
 */
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      console.log('sw: writing files into cache');
      return cache.addAll(filesToCache);
    })
  )
}); 
/**
 * 'Activate' event. Service worker is activated
 *
 * @param {string} Event name ('activate')
 * @param {function} Callback function with event data
 *
 */
self.addEventListener('activate', function (event) {
  console.log('sw: service worker ready and activated', event);
}); 
/**
 * 'Fetch' event. Browser tries to get resources making a request
 *
 * @param {string} Event name ('fetch')
 * @param {function} Callback function with event data
 *
 */
self.addEventListener('fetch', function(event) {
  event.respondWith( 
    caches.match(event.request).then(function(response) { 
      return response || fetch(event.request);
    }).catch(function (err) { 
      return caches.match('img/offline-img.png');
    })
  )
}); 